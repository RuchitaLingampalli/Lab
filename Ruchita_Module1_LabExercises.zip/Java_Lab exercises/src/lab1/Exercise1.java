package lab1;
import java.util.Scanner;
class Calculation
{
	int calculateSum(int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0)
			{
				sum=sum+i;
		
			}
			
		}
		return sum;
		
	}
}
public class Exercise1
{
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		scan.close();
		Calculation ob=new Calculation();
		System.out.println("Calculate Sum="+ob.calculateSum(n));
	}
}
