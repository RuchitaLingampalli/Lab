package lab1;
import java.util.Scanner;
class Difference
{
	int calculateDifference(int n)
	{
		int diff=0,sum1=0,sum2=0;
		for(int i=1;i<=n;i++){
			{
				
		}
			sum1=sum1+(i*i);
		}
		for(int j=1;j<=n;j++)
		{
			sum2=(sum2+j);
			sum2=(sum2*sum2);
		}
		diff=sum1-sum2;
		return diff;
		
		}
			}

public class exercise2 {
	public static void main (String args[])
	{
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		scan.close();
		Difference ob1=new Difference();
		System.out.println("Calculation difference="+ob1.calculateDifference( n));
		}

}
