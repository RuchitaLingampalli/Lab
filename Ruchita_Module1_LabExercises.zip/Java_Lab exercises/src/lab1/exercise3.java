package lab1;
import java.util.Scanner;
public class exercise3 {
	public static void main(String args[]) {
	boolean flag=false;
	Scanner scan=new Scanner(System.in);
	int num=scan.nextInt();
	 scan.close();
	int currentDigit=num%10;{
		num=num/10;
		while (num>10) {
			if(currentDigit<=num%10)
				flag=true;
			break;
			 }
		currentDigit=num%10;
		num=num/10;
		if(flag) {
			System.out.println("not an increasing number");
		}
		else {
			System.out.println("Increasing number");
		
		     
		}
	
	 }
	}
}
	 