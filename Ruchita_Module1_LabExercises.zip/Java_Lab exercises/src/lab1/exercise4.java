package lab1;
import java.util.Scanner;
public class exercise4 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		if(checkNumber(n))
			System.out.println(n+"is power of 2");
		else
			System.out.println(n+"not power of 2");
	}
	static boolean checkNumber(int n)
	{
		while(n>1)
		{
			if(n%2!=0)
			{
				return false;
			}
			n=n/2;
			}
		return true;  
		}
	}

