package lab10;
import java.util.Date;

public class Exercise2 implements Runnable {
  Thread t=new Thread(this);
  
  public Exercise2() throws InterruptedException{
	  t=new Thread(this);
	  t.start();
  }

@Override
public void run() {
	// TODO Auto-generated method stub
	Date date;
	while(true) {
		try {
			date=new Date();
			Thread.sleep(6000);
			System.out.println(date.getHours()+ ":"+date.getMinutes()+ ":"+date.getSeconds());
		}catch(InterruptedException e) {
			System.out.println("This Exception should not come.");
		}
		
	}
}
  public static void main(String args[]) throws InterruptedException {
	  //Thread t=new Thread();
	  Exercise2 ex=new Exercise2();
  }
}
