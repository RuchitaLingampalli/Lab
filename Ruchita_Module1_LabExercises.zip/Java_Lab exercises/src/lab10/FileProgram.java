package lab10;
import java.io.*;
public class FileProgram {
	public static void main(String args[]) {
		try {
			FileInputStream fisObj = new FileInputStream("C:\\Users\\rulingam\\Desktop\\java1.txt");
			FileOutputStream fosObj = new FileOutputStream("C:\\Users\\rulingam\\Desktop\\filet.txt");
			CopyDataThread cdt=new CopyDataThread(fisObj,fosObj);
			cdt.start();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
