package lab11;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MusicPlayTask implements Runnable{
	public void run() {
			System.out.println("MusicPlayTask is executing");
  try {
	  Thread.sleep(6000);
  }catch(Exception e) {
	System.out.println(e);
	}
  System.out.println("MusicPlayTask is resumed after sleep");
	}
	}

 class CopyTask implements Runnable {
public void run() {
	System.out.println("copytask is executing");
	try {
		Thread.sleep(6000);
	}catch(Exception e) {
		System.out.println(e);
	}
	System.out.println("copytask is resumed after sleep");
}
}


public class Exercise1 {
public static void main(String args[]) {
 Scanner sc=new Scanner(System.in);
 System.out.println("Thread Executor & Service Demo \n 1.Executor  \n 2.Executor Service \n Enter your choice:");
 int ch=sc.nextInt();
 if(ch==1) {
	 Executor e=Executors.newSingleThreadExecutor();
		e.execute(new MusicPlayTask());
		e.execute(new CopyTask());
 }
 else if(ch==2) {
	 ExecutorService ec1=Executors.newSingleThreadExecutor();
	 ExecutorService ec2=Executors.newFixedThreadPool(8);
	 ec2.execute(new MusicPlayTask());
	 ec2.execute(new CopyTask());
	 ec2.shutdown();
 }
 else {
	 System.out.println("Enter a valid choice.");
 }
 sc.close();
}
}
