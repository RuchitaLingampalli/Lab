package lab13;

public interface CustomerDetails {

}
