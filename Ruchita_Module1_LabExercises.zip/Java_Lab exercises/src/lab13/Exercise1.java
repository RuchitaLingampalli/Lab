package lab13;
interface Power{
	double calcPower(double x,double y);
}
public class Exercise1 {
public static void main(String args[]) {
	Power p=(x,y)->Math.pow(x,y);
	double z=p.calcPower(4,5);
	System.out.println(z);
}
}
