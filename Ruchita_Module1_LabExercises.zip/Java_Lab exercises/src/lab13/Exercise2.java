package lab13;
import java.util.Scanner;
interface Space{
	String space(String a);
}
public class Exercise2{
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		Space p=(r)->giveSpace(r);
		System.out.println(p.space(s));
		sc.close();
	}
	static String giveSpace(String s1) {
		String d="";
		for(int i=0;i<s1.length();i++) {
			d=d+s1.charAt(i)+" ";
		}
		return d;
	}
}