package lab13;
import java.util.Scanner;
interface UserName{
	boolean username(String username,String password);
}
public class Exercise3 {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the username:");
	String su=sc.next();
	System.out.println("Enter the Password:");
	String sp=sc.next();
	UserName up=(x,y)->Authentication(x,y);
	if(up.username(su,sp))
		System.out.println( "Successful Login");
	else
		System.out.println("Login Fails");
	sc.close();
}

static boolean Authentication(String a,String b) {
	boolean val=false;
	String username="Ruchita";
	String password="ruchi@123";
			if(a.equals(username)&&b.equals(password)) {
				return true;
				
				
			}
			return val;
			
			
}
}
