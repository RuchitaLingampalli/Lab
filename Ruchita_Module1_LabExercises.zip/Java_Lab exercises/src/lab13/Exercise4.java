package lab13;
import lab13.Customer.CustomerDetails;
class Customer{
	String Name;
	int cusID;
public Customer(String Name,int cusID) {
	this.Name=Name;
	this.cusID=cusID;
	
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public int getCusID() {
	return cusID;
}
public void setCusID(int cusID) {
	this.cusID = cusID;
}
interface CustomerDetails{
	public Customer getCustomer(String Name,int cusID);
}
}
public class Exercise4 {
	public static void main(String args[]) {
		CustomerDetails cs= Customer::new;
		Customer c=cs.getCustomer("Ruchita",345);
		System.out.println("Customer name:"+c.getName());
		System.out.println("Customer id:"+c.getCusID());
	}
	}
	
		
			

		
			
			
			
			
			

