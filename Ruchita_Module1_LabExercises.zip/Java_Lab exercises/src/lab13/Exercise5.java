package lab13;
interface Factorial{
	long fact(long x);
}
public class Exercise5{
	public long factorial(long n) {
		long f=1;
		while(n>0) {
			f=f*n;
			n--;
		}
		System.out.println(f);
		return f;
	}
	public static void main(String args[]) {
		Exercise5 ex=new Exercise5();
		Factorial fac=ex::factorial;
		System.out.println(fac.fact(40));
	}
}