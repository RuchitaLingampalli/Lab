package lab2;
import java.util.Scanner;
abstract class Item {
private int identificationNumber() {
	return identificationNumber();
}
private char title() {
	return title();
}
private int numberofCopies() {
	return numberofCopies();
}
}
class WrittenItem extends Item{
	private char author()
{
		return author();
		}
}
class Book extends WrittenItem{
	//Super();
	}
class JournalPaper extends WrittenItem{
	private int year() {
		return year();
			}
	class MedianItem extends Item{
		private int runTime() {
			return runTime();
			
			}
		class Vedio extends MedianItem{
			private char director() {
				return director();
			}
			private char genre() {
				return genre();
			}
			private int year() {
				return year();
			}
			class Cd extends MedianItem{
				private char artist() {
					return artist();
				}
				private char genre() {
					return genre();
					
				}
			}
		}
	}
}
public class Exercise1 {
	public static void main(String []args) {
	
	}
}
