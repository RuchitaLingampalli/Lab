package lab3;

public class Exercise1 {
	static int getSecondSmallest(int a[] ) {
		int temp;
		int n=5;
		for( int i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
				
			}
		}
		
	return a[1];
	}


public static void main(String args[])
{
	int a[]= {5,9,12,4,2};
	System.out.println("second smallest:"+getSecondSmallest(a));
}
}
