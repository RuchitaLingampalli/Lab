package lab3;
import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {
 static void sortarray(String str[],int size)
 {
	 Arrays.sort(str);
	 int t=size/2;
	 if(size%2!=0)
	 {
		 t=t+1;
	 }
	 for(int i=0;i<size;i++)
	 {
		 if(i<t)
		 {
			 System.out.println(str[i].toUpperCase());
		 }
		 else
		 {
			 System.out.println(str[i]);
		 }
	 }
 }
 public static void main(String args[]) {
	 Scanner sc=new Scanner(System.in);
	 int size=sc.nextInt();
	 String str[]=new String[size];
	 for(int i=0;i<size;i++)
	 {
		 str[i]=sc.next();
		 str[i]=str[i].toLowerCase();
		 }
	 sortarray(str,size);
 }
}
