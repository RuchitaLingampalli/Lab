package lab3;
import java.util.Scanner;
public class Exercise4 {
 public static void main(String args[]) {
	 Scanner sc=new Scanner(System.in);
	String str=sc.next();
	sc.close();
	CountChar(str);
 }
 static void CountChar(String str)
 {
	 int count[]=new int[150];
	 int i=0,f=0;
	 for(i=0;i<str.length();i++)
		 count[str.charAt(i)]++;
	 char ch[]=new char[str.length()];
	 for(i=0;i<str.length();i++)
	 {
		 ch[i]=str.charAt(i);
		 f=0;
		 for(int j=0;j<=i;j++) {
			 if(str.charAt(i)==ch[j])
				 f++;
		 }
		 if(f==1)
			 System.out.println("no of occurance of"+str.charAt(i)+" "+ "is:" +count[str.charAt(i)]);
		 }
	 }
 }
 
