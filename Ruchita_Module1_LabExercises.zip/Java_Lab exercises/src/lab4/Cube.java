package lab4;
import java.util.Scanner;


public class Cube {
	public static void main(String args[])
	{
		int res=0,sum=0;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		while(n!=0)
		{
			int rem=n%10;
			res=rem*rem*rem;
			sum=res+sum;
			n=n/10;
		}
		System.out.println(sum);
	}

}
