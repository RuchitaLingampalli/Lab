package lab5;
enum TrafficSg
	{
		RED,GREEN,YELLOW
	}
public class Exercise1 {
	TrafficSg color;
   public Exercise1(TrafficSg color)
		{
			this.color=color;
			
		}
	public void selectColor()
	{
		switch(color)
		{
		case RED:
			System.out.println("WAIT");
			break;
		case GREEN:
			System.out.println("GO");
			break;
		case YELLOW:
			System.out.println("SLOW");
			break;	
			default:
				System.out.println("wrong selection");
				break;
		}
	}
	public static void main(String args[])
	{
		Exercise1 tObj=new Exercise1(TrafficSg.GREEN);
		tObj.selectColor();
		}
	}

