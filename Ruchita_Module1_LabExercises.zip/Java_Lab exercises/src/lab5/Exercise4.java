package lab5;
import java.util.*;

class FullNameException extends NullPointerException{}
public class Exercise4 {
	public static void main(String args[])throws Exception{
		Scanner sc=new Scanner(System.in);
		String firstname=null;
		
		String lastname=null;
				
				sc.close();
				try {
					if(firstname==null  || lastname==null)
						System.out.println("firstname and lastname should not be blank!");
					else
						System.out.println("firstname:"+firstname+" "+"lastname:"+lastname);
				}
				catch(Exception e) {
					System.out.println(e);
					
				}
						
				
				
				
	}

}
