package lab5;
import java.util.Scanner;
class WrongAgeException extends RuntimeException{
WrongAgeException() {
	System.out.println("Wrong age");
}
WrongAgeException(String a){
	System.out.println("WrongAgeException:"+a);
	
}
}

public class Exercise5 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age:");
       int age=sc.nextInt();
       sc.close();
   try {
	if(age<15)
		throw new WrongAgeException("Wrong age");
	else
		System.out.println("age:"+age);
}
    
   catch (Exception e) {
	System.out.println();
	
		}
		
		
	}
}
