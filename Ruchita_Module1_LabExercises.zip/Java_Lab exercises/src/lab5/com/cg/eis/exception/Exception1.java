package lab5.com.cg.eis.exception;
import java.util.Scanner;
class EmployeeException extends RuntimeException{
	EmployeeException(){
		System.out.println("low salary");
		
	}
	EmployeeException(String a){
		System.out.println("low salary:"+a);
	}
}
public class Exception1 {
public static void main(String args[]) {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("enter salary:");
	  
	  
		  int salary=sc.nextInt();
  
  sc.close();
  try{
	
		 if (salary<3000)
			 throw new EmployeeException("salary below 3000");
		 else
			 System.out.println("salary is:"+salary);
		  }
  catch(Exception e) {
	  System.out.println();
	}
  }
}
