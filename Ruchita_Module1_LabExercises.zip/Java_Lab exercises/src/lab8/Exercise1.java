package lab8;
import java.util.*;

public class Exercise1 {
	public static void main(String args[]) {
		int n;
		int sum=0;
		System.out.println("enter a string:");
		Scanner sc=new Scanner (System.in);
		String s=sc.nextLine();
		StringTokenizer st=new StringTokenizer(s," ");
		while(st.hasMoreTokens()) {
			n=Integer.parseInt(st.nextToken());
			System.out.println(n);
			sum=sum+n;
		}
		System.out.println("sum:"+sum);
	}
}
		
			

		



