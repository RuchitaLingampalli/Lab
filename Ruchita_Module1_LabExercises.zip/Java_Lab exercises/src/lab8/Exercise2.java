package lab8;
import java.io.*;
public class Exercise2 {
public void readRAF() throws IOException{
	try {
		RandomAccessFile rafObj=new RandomAccessFile("C:\\Users\\rulingam\\Desktop\\java1.txt","r");
		String a;
		int line=1;
		while((a=rafObj.readLine())!=null) {
			System.out.println(line +a);
			line++;
		}
		rafObj.close();
	}catch(Exception e) {
		System.out.println(e);
			
		}
			
		}
public static void main(String args[]) throws IOException{
	Exercise2 ex2=new Exercise2();
    	ex2.readRAF();
}
		
	}
		
	
	
