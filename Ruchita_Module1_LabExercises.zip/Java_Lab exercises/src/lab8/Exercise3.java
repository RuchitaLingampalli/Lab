package lab8;
import java.util.*;
import java.io.*;
public class Exercise3 {
public static void main(String args[]) {
	System.out.println("enter a text:");
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	sc.close();
	int count=1;
	for(int i=0;i<s.length();i++)
	{
		if(s.charAt(i)==' '&& s.charAt(i+1)!=' ')
		{
			count++;
		}
}
System.out.println("words"+count);
int count1=0;
for(int i=0;i<s.length();i++)
{
	if(s.charAt(i)!=' ')
	{
		count1++;
	}
}
System.out.println("Characters:"+count1);
}
}