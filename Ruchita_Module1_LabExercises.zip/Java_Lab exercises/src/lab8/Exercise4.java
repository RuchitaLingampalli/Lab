package lab8;
import java.io.*;
import java.util.Scanner;

public class Exercise4 {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	File f=new File("C:\\Users\\rulingam\\Desktop\\java1.txt");
	System.out.println("Name:"+f.getName());
	System.out.println("File:"+(f.exists()?"exists":"does not exist"));
	System.out.println("file is readable:"+f.canRead());
	System.out.println("File is writable:"+f.canWrite());
	System.out.println("File length:"+f.length());
	
}
}
