package lab8;
import java.util.Scanner;
public class Exercise5 {
	static boolean PositiveString(String s) {
		int n=s.length();
		for(int i=1;i<n;i++) {
			if(s.charAt(i)<s.charAt(i-1))
				return false;
		}
		return true;
	}
	public static void main(String args[]) {
		System.out.println("enter a string");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		if(PositiveString(s)) {
			System.out.println("Positive string");
	}
	else {
		System.out.println("Not a positive string");
	}
}
}
