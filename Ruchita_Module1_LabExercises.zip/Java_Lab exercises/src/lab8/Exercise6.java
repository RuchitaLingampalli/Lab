package lab8;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

public class Exercise6{
	public static void main(String args[]) {
		LocalDate pdate=LocalDate.of(2014,9,06);
		LocalDate cdate=LocalDate.now();
		Period diff=Period.between(pdate,cdate);
		System.out.println("\nduration in days:"+diff.getDays()+"\nduration in months:"
		+diff.getMonths()+"\nduration in years:"+diff.getYears());
		


}
}