package lab8;
import java.util.Scanner;
public class Exercise7 {
	  public static boolean check(String name) {
	        String str = name.substring(0,name.length()-4);
	        if(name.substring(8,name.length()).equals("_job") && str.length()==8) {
	            return true;
	        }
	        else
	            return false;
	    }
	public static void main(String args[]) {
	    System.out.println(check("ruchi697_job"));
	}
	}

