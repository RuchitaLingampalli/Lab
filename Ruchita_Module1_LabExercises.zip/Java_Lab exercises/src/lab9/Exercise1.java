package lab9;
import java.util.*;
class Maps{
	int id;
	String name;
Maps(int cid,String nm)	{
	id= cid;
	name=nm;
}
@Override
public String toString() {
	return "Maps [id=" + id + ", name=" + name + "]";
}
}


public  class Exercise1 {
	ArrayList getValues(HashMap mp) {//Method getValues
		Collection values=mp.values();
		ArrayList lists=new ArrayList(values);
		return lists;//return type List
		
	}
 public static void main(String args[]) {
	 Scanner sc=new Scanner(System.in);
	 Exercise1 ex=new Exercise1();
	 Maps ex1= new Maps(40,"Meghana");
	 Maps ex2= new Maps(20,"Sahithi");
	 Maps ex3= new Maps(30,"Mounika");
	 HashMap<Integer,Maps> hm=new HashMap<Integer,Maps>();
	 hm.put(1, ex1);
	 hm.put(2, ex2);
	 hm.put(3, ex3);
	 System.out.println(ex.getValues(hm));
	 sc.close();
 }
}

