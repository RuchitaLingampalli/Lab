package lab9;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class Exercise2 {
HashMap countCharacter(char[]ch) {
	HashMap<Character,Integer> hm1=new HashMap<Character,Integer>();
	int l=ch.length;
	int count=0,flag=0;
	for(int i=0;i<l;i++) {
		count=0;
		for(int j=0;j<l;j++)
			if(ch[j]==ch[i])
				count++;
				for (int k=0;k<i;k++)
					if(ch[k]==ch[i])
						flag=1;
				flag=0;
				hm1.put(ch[i],count);
	}
	return hm1;
}
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	char ch[]=new char[50];
	System.out.println("Enter a String:");
	ch=sc.next().toCharArray();
	Exercise2 ex=new Exercise2();
	HashMap<Character,Integer>hm=new HashMap<Character,Integer>();
	hm=ex.countCharacter(ch);
	for(Map.Entry mp:hm.entrySet()) {
		char key=(char)mp.getKey();
		Integer count=(Integer)mp.getValue();
		System.out.println(key+" : "+count);
	}
	sc.close();
	}
}
