package lab9;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise3 {
	HashMap countSquares(int[] ch)
	{
		HashMap<Integer,Integer> hm1=new HashMap<Integer,Integer>();
		int l=ch.length;
		int sq[] = new int[1];
		for(int i=0;i<l;i++) {
			sq[i]=ch[i]*ch[i];
			hm1.put(ch[i],sq[i]);
		}
	return hm1;
		
	}             
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int ch[]=new int[n];
		System.out.println("enter a string:");
		for(int i=0;i<n;i++) {
			ch[i]=sc.nextInt();
		}
		Exercise3 ex=new Exercise3();
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm=ex.countSquares(ch);
		for(Map.Entry mp:hm.entrySet()) {
			char key=(char)mp.getKey();
			Integer count=(Integer)mp.getValue();
			System.out.println(key+" : "+count);
		}
		sc.close();
		}
	}

